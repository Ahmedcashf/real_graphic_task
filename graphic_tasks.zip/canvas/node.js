const canvas = document.getElementById("myCanvas");
let c = canvas.getContext("2d");

let circles = [];

function Circle ( x,y,dx,dy,radius ) {
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.radius = radius;


    this.draw = function() {
        c.beginPath();
        c.arc(this.x , this.y , this.radius , 0 , Math.PI * 2);
        c.fill();
        c.fillStyle = "red";
    }


    this.updateCircle = function () {
        if (this.x + this.radius > 300 || this.x - this.radius < 0) {
            this.dx = -this.dx
        }

        if (this.y + this.radius > 400 || this.y - this.radius <0) {
            this.dy = -this.dy
        }

        this.x += this.dx;
        this.y += this.dy;

        this.draw()
    }
}

for (let i = 0 ; i < 50 ; i++) {
    let radius = 20;
    let randomx = Math.random() * (300 - radius * 2) + radius;
    let randomy = Math.random() * (400 - radius * 2) + radius;
    let dx = (Math.random() - .5) * 5;
    let dy = (Math.random() - .5) * 5;
    let circle = new Circle ( randomx,randomy,dx,dy,radius );
    circles.push(circle);
}

function animate() {
    requestAnimationFrame(animate);
    
    c.clearRect(0,0,canvas.width,canvas.height);
    for (let i = 0 ; i < circles.length ; i++) {
        circles[i].updateCircle();
    }
}

animate();